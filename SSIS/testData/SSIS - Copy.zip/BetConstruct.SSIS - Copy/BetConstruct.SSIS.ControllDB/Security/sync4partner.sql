﻿CREATE SCHEMA [sync4partner]
    AUTHORIZATION [dbo];

