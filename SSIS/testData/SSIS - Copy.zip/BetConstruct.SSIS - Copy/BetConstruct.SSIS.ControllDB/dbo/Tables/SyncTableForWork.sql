﻿CREATE TABLE [dbo].[SyncTableForWork] (
    [Name]    [sysname] NOT NULL,
    [ToCopy]  BIT       NULL,
    [ToStage] BIT       NOT NULL
);

