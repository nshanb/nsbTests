﻿CREATE TABLE [dbo].[testSyncTable] (
    [Name]    [sysname] NOT NULL,
    [ToCopy]  BIT       NULL,
    [ToStage] BIT       NOT NULL
);

